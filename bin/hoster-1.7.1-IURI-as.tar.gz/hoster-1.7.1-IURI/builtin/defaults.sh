#!/usr/bin/env bash
#
function define_defaults(){
    DEFAULT_IDE=$1;

    FILE_PATH=$2;
    FILE=$3;

    network=$4;
}