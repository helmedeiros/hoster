#!/bin/bash
rm /Library/Caches/Homebrew/hoster-0.1.tar.gz 
brew remove --verbose --debug hoster
brew install --verbose --debug hoster
ls -lsa /usr/local/Cellar/hoster/0.1/
